x = ( 144, 0, 720, 0,
      360, 240, 0, 0,
      0, 0, 0, 169 )

Ukupna ostvarena zarada: 19920.0